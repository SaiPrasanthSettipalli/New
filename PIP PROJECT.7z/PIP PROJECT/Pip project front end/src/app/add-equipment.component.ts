import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-equipment',
  templateUrl: './add-equipment.component.html',
  styleUrls: ['./add-equipment.component.css']
})
export class AddEquipmentComponent implements OnInit {
  selectedFiles:FileList;
  equipment:String;
  Price:number;
  currentFileUpload:File;
  dataone:any[];
  result:any
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
  
 } 
 add2(){
  this.router.navigate(["./addTests"]);
}
logout(){
  this.router.navigate(['./home']);
 
}
view2(){
  this.router.navigate(['./viewTests']);
}
view1(){
  this.router.navigate(['./viewEquipment']);
}

submit(){
  
  this.managerService.addEquipment(this.equipment,this.Price).subscribe((data:number)=>{
    this.result=data;
    if(this.result==1){
    alert("equipment added successfully")
    this.router.navigate(['./viewEquipment']);
    }
    else if(this.result==2)
    alert("This Equipment added already")
    else
    alert("Enter the required fields");
  })
}
}
