import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-tesst',
  templateUrl: './edit-tesst.component.html',
  styleUrls: ['./edit-tesst.component.css']
})
export class EditTesstComponent implements OnInit {

  tName:any;
  tPrice:any;
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
    this.tName=this.managerService.tName;
    this.tPrice=this.managerService.tPrice;
  }
save(tPrice:any){
  return this.managerService.saveEditedTest(tPrice).subscribe((data:any)=>{
    if(data==1)
    {
      alert("updated successfully");
      this.router.navigate(['./viewTests']);
    }
  })
}
}
