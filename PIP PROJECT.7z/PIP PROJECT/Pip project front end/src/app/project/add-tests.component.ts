import { Component, OnInit } from '@angular/core';
import { ManagerService } from '../manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-tests',
  templateUrl: './add-tests.component.html',
  styleUrls: ['./add-tests.component.css']
})
export class AddTestsComponent implements OnInit {
  data:any={};
  res:number;
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
  }

  submit(){
    return this.managerService.submitTest(this.data).subscribe((data1:number)=>
      {this.res=data1;
        if(this.res==1){
        alert("Test added successfully")
        this.router.navigate(['./viewTests']);
        }
        else if(this.res==2)
        alert("This test added already");
        else
        alert("Enter the required fields");
      });
  
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }

  view1(){
    this.router.navigate(['./viewEquipment']);
  }
}

