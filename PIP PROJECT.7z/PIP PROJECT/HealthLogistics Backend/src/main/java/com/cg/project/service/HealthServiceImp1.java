package com.cg.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;
import com.cg.project.dao.HealthDao;

@Service
public class HealthServiceImp1 implements HealthService{

	@Autowired
	HealthDao healthDao;
	@Override
	public Integer createRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return healthDao.createRegistration(registration);
	}
	@Override
	public Integer addTests(Logistics logistics) {
		// TODO Auto-generated method stub
		return healthDao.addTests(logistics);
	}
	@Override
	public List<Registration> getUserDetails() {
		return healthDao.getUserDetails();
	}
	
	@Override
	public Integer validateByMailPswd(String mailId, String pswd) {
		return healthDao.validateByMailPswd(mailId,pswd);
	}
	@Override
	public List<Registration> getTechnicianDetails() {
		return healthDao.getTechnicianDetails();
	}
	@Override
	public Integer booking(String usermail, String tecnicianMail) {
		return healthDao.booking(usermail, tecnicianMail);
	}
	@Override
	public List<Registration> getDetails(String technicianMail) {
		return healthDao.getDetails(technicianMail);
	}
	@Override
	public List<Logistics> viewTests() {
		return healthDao.viewTests();
	}
	@Override
	public Integer addEquipment(String name, Integer price) {
		return healthDao.addEquipment(name,price);
	}
	@Override
	public List<Logistics> getEquipment() {
		return healthDao.getEquipment();
	}
	@Override
	public Integer saveChanges(String ename, Integer eprice) {
		return healthDao.saveChanges(ename,eprice);
	}
	@Override
	public void deleteEquipment(String ename) {
		healthDao.delete(ename);
		
	}
	@Override
	public Integer saveTestChanges(String tname, Integer tprice) {
		return healthDao.saveTestChanges(tname,tprice);
	}
	@Override
	public void deleteTests(String tname) {
		healthDao.deleteTests(tname);
		
	}
	

}
