package com.cg.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.cg.project")
@SpringBootApplication
public class HealthLogisticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthLogisticsApplication.class, args);
		System.out.println("welcome to health logistics");
	}

}
