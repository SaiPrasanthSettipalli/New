package com.cg.project.dao;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;
@Repository
public class HealthDaoImp1 implements HealthDao{

	@Autowired
	MongoTemplate mongotemplate;
	
	@Override
	public Integer createRegistration(Registration registration) {
		
		List<Registration> details=mongotemplate.findAll(Registration.class);
		for(Registration registrationDetails:details) {
			if(registrationDetails.getMailId().equals(registration.getMailId()))
				return 1;
			}
			mongotemplate.insert(registration);
			return 2;
			
		}

	@Override
	public Integer addTests(Logistics logistics) {
		List<Logistics> details=mongotemplate.findAll(Logistics.class);
		if(logistics.getTestName()==null || logistics.getTestPrice()==0 )
			return 0;
		else
		{
			for(Logistics result:details) {
				if(result.getTestName()!=null && result.getTestPrice()!=0)
				if(result.getTestName().equals(logistics.getTestName()))
					return 2;
			}
		}
		 mongotemplate.insert(logistics);
		return 1;
	}

	@Override
	public List<Registration> getUserDetails() {
		List<Registration> details=mongotemplate.findAll(Registration.class);
		List<Registration> userDetails=new ArrayList<>();
		for(Registration registrationDetails:details) {
			if(!(registrationDetails.getUserName().equalsIgnoreCase("manager") || registrationDetails.getUserName().equalsIgnoreCase("technician")))
				userDetails.add(registrationDetails);
		}
		return userDetails;
	}

	

	@Override
	public Integer validateByMailPswd(String mailId, String pswd) {

		System.out.println("indao"+ pswd);
		Registration user=mongotemplate.findOne(Query.query(Criteria.where("mailId").is(mailId)),Registration.class);
		    if(user==null)
		    {
		    	return 0;
		    }
		    else {
		    if(user.getPassword().equals(pswd))
		    {
		    	String userName=user.getUserName();
		    	if(userName.equalsIgnoreCase("manager"))
		    		return 1;
		    	else if(userName.equalsIgnoreCase("technician"))
		    		return 2;
		    	else
		    		return 3;
		    }
		}
		    return 0;
	}

	@Override
	public List<Registration> getTechnicianDetails() {
		// TODO Auto-generated method stub
		List<Registration> details=mongotemplate.findAll(Registration.class);
		List<Registration> technicianDetails=new ArrayList<>();
		for(Registration technician:details) {
			if(technician.getUserName().equalsIgnoreCase("technician")) {
				technicianDetails.add(technician);
				
			}
		}
		return technicianDetails;
	}

	@Override
	public Integer booking(String usermail, String tecnicianMail) {
		// TODO Auto-generated method stub
		Registration user=mongotemplate.findOne(Query.query(Criteria.where("mailId").is(usermail)),Registration.class);
		user.setTechnicianMail(tecnicianMail);
		mongotemplate.save(user);
		return 1;
	}

	@Override
	public List<Registration> getDetails(String technicianMail) {
		List<Registration> users=getUserDetails();
		List<Registration> userDetails=new ArrayList<>();
		for(Registration details:users) {
			if(details.getTechnicianMail()!=null)
			if(details.getTechnicianMail().equalsIgnoreCase(technicianMail))
				userDetails.add(details);
		}
		return userDetails;

	}

	@Override
	public List<Logistics> viewTests() {
		List<Logistics> testDetails=mongotemplate.findAll(Logistics.class);
		List<Logistics> details=new ArrayList<>();
		for(Logistics result:testDetails)
		{
			if(result.getTestName()!=null && result.getTestPrice()!=0)
				details.add(result);
		}
		
		return details;
	
	}

	@Override
	public Integer addEquipment(String name, Integer price) {
		// TODO Auto-generated method stub
		List<Logistics> details=mongotemplate.findAll(Logistics.class);
		if(name==null || price==0 )
			return 0;
		else
		{
			for(Logistics result:details) {
				if(!(result.getEquipmentName()==null)) {
					System.out.print(result.getEquipmentName()+" "+name);
				if(result.getEquipmentName().equalsIgnoreCase(name))
				{
					System.out.println(result.getEquipmentName());
					return 2;
				}
			}
			}
		}
		Logistics logistics=new Logistics();
		logistics.setEquipmentName(name);
		logistics.setEquipmentPrice(price);
		 mongotemplate.insert(logistics);
		return 1;
	}

	@Override
	public List<Logistics> getEquipment() {
		
		List<Logistics> equipmentDetails=mongotemplate.findAll(Logistics.class);
		List<Logistics> details=new ArrayList<>();
		for(Logistics result:equipmentDetails)
		{
			if(result.getEquipmentName()!=null && result.getEquipmentPrice()!=0)
				details.add(result);
		}
		
		return details;
	}

	@Override
	public Integer saveChanges(String ename, Integer eprice) {
		// TODO Auto-generated method stub
		Logistics equip=mongotemplate.findOne(Query.query(Criteria.where("equipmentName").is(ename)),Logistics.class);
		Logistics log=new Logistics();
		System.out.println(equip);
		if(equip.getEquipmentPrice()!=0)
		{
			 mongotemplate.remove(Query.query(Criteria.where("equipmentName").is(ename)), Logistics.class);
			log.setEquipmentName(ename);
			log.setEquipmentPrice(eprice);
			System.out.println(log);
			mongotemplate.insert(log);
			
		}
		return 1;
	}

	@Override
	public void delete(String ename) {
		// TODO Auto-generated method stub
		System.out.println(ename);
		mongotemplate.remove(Query.query(Criteria.where("equipmentName").is(ename)), Logistics.class);
		
	}

	@Override
	public Integer saveTestChanges(String tname, Integer tprice) {
		Logistics equip=mongotemplate.findOne(Query.query(Criteria.where("testName").is(tname)),Logistics.class);
		Logistics log=new Logistics();
		System.out.println(equip);
		if(equip.getTestPrice()!=0)
		{
			 mongotemplate.remove(Query.query(Criteria.where("testName").is(tname)), Logistics.class);
			log.setTestName(tname);
			log.setTestPrice(tprice);
			System.out.println(log);
			mongotemplate.insert(log);
			
		}
		return 1;
	}

	@Override
	public void deleteTests(String tname) {
		// TODO Auto-generated method stub
		mongotemplate.remove(Query.query(Criteria.where("testName").is(tname)), Logistics.class);
	}
}


