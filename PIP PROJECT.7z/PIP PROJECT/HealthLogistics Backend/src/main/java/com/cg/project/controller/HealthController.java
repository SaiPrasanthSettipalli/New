package com.cg.project.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;
import com.cg.project.service.HealthService;

@RestController
@RequestMapping("/registration")
@CrossOrigin(origins="http://localhost:4200")
public class HealthController {

	@Autowired
	HealthService service;

	//This is for creating a registration page
	@PostMapping("/userregistration")
	public Integer createRegistrationUser(@RequestBody Registration registration) {
		return service.createRegistration(registration);
		}
	
	//This is for adding tests 
	@PostMapping("/addTests")
	public Integer addTests(@RequestBody Logistics logistics) {
		return service.addTests(logistics);
		}
	//This is to view all the tests that are added
	@GetMapping("/viewTests")
	public List<Logistics> viewTests(){
		return service.viewTests();
	}
	
	//This is to get all user details from the database
	@GetMapping("/getuserDetails")
	public List<Registration> getDetails() {
		return service.getUserDetails();
	}
	
	//This is to add all equipment details like equipment name and equipment price
	@GetMapping("/addEquipment/{name}/{price}")
	public Integer addEquipment(@PathVariable("name") String name,@PathVariable("price") Integer price) {
		
		return service.addEquipment(name,price);
	}
	
	//This is for login validation
	@PostMapping("/validateUser")
	public Integer validateByMailPswd(@RequestParam("mailId") String mailId,@RequestParam("password") String pswd) {
		return service.validateByMailPswd(mailId,pswd);
		
	}
	
	//This is to get all the technician details from database`
	@GetMapping("/getTechnicianDetails")
	public List<Registration> getTechnicianDetails(){
		return service.getTechnicianDetails();
	}
	
	//This is for booking the technician
	@GetMapping("/Booking/{usermail}/{tecnicianMail}")
	public Integer booking(@PathVariable("usermail") String usermail,@PathVariable("tecnicianMail") String tecnicianMail) {
		return service.booking(usermail,tecnicianMail);
		}
	
	//This is to get the details of users who booked that technician
	@GetMapping("/getDetails/{technicianMail}")
	public List<Registration> getDetails(@PathVariable("technicianMail") String technicianMail){
		return service.getDetails(technicianMail);
		
	}
	
	//This is to view all the equipment that is added
	@GetMapping("/viewEquipment")
	public List<Logistics>getEquipment(){
		System.out.println("hello");
		return service.getEquipment();
		
	}
	
	//This is to save the changes that are made in equipment price and equipment name
	@GetMapping("/saveChanges/{ename}/{eprice}")
	public Integer saveChanges(@PathVariable("ename") String ename,@PathVariable("eprice") Integer eprice) {
		return service.saveChanges(ename,eprice);
		
	}
	
	//This is to delete the equipment details
	@DeleteMapping("/delete/{ename}")
	public Integer delete(@PathVariable("ename") String ename) {
		System.out.println(ename);
		service.deleteEquipment(ename);
		return 1;
	}
	
	//This is to delete the tests 
	@DeleteMapping("/deletetests/{tname}")
	public Integer deletetest(@PathVariable("tname") String tname) {
		System.out.println(tname);
		service.deleteTests(tname);
		return 1;
	}
	
	//This is to save changes that are made to test name and test price
	@GetMapping("/saveTestChanges/{tname}/{tprice}")
	public Integer saveTestChanges(@PathVariable("tname") String tname,@PathVariable("tprice") Integer tprice) {
		return service.saveTestChanges(tname,tprice);
		
	}
}
