const path = require('path');
var grid = require("gridfs-stream");
var fs = require("fs");

module.exports.writeToDB = function (id,fn, connection, mongooseDrv) {
    if (connection !== "undefined") {
        console.log(connection.readyState.toString());

        grid.mongo = mongooseDrv.mongo;

        var gridfs = grid(connection.db);
        if (gridfs) {
            var fsstreamwrite = fs.createWriteStream(
                path.join(__dirname, "./filestowrite/"+fn)
            );

            var readstream = gridfs.createReadStream({
                filename: "billgates.jpg"
            });
            readstream.pipe(fsstreamwrite);
            readstream.on("close", function (file) {
                console.log("File Read successfully from database");
            });
        } else {
            console.log("Sorry No Grid FS Object");
        }
    }
    console.log("done");
}

