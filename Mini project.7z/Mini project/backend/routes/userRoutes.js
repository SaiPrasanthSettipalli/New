// for routes
const express = require('express');
// for mongoose third party module
const mongoose = require('mongoose');
// for connection string
const config = require('../config/db');
// configuring router OR Creating an object of Router
const router = express.Router();
//import from quote.model.js Module
let User = require('../model/user.model');

// STEP3 - CONNECT MONGODB DATABASE
//Connecting Mongodb server
mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;
//when connection open
db.once('open', function () {
    console.log('Connection Open with MongoDB Server ..!');
});
//check for db error
db.on('error', function (err) {
    console.log("Error : " + err.stack);
});

// GET /api/users
router.route('/users').get(function (req, res) {
    User.find(function (err, users) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        res.status(200).json(users);
    });
});

// 	User.findById(req.params.id, 'firstName lastName age mobileNumber email password',
// GET /api/users/1
router.route('/users/:id')
    .get(function (req, res) {
        User.findById(req.params.id, { __v: 0 },
            function (err, user) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json(user);
            });
    });

// CREATE - POST - /api/users
router.route('/users').post(function (req, res) {
    var user = new User();
    user.firstName = req.body.firstName;
    user.lastName = req.body.lastName;
    user.age = req.body.age;
    user.mobileNumber = req.body.mobileNumber;
    user.email = req.body.email;
    user.password = req.body.password;

    user.save(function (err) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        console.log("added");
        res.status(200).json({
            message
                : 'User Created !'
        })
    })
});

// DELETE /api/users/1
router.route('/users/:id')
    .delete(function (req, res) {
        // remove(), findByIdAndRemove(), deleteOne()
        User.deleteOne({ _id: req.params.id },
            function (err, user) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json({
                    message:
                        'User successfully deleted'
                });
            })

        // User.remove({ _id: req.params.id },
        //     function (err, user) {
        //         if (err) {
        //             res.status(500).json(err.stack);
        //             return;
        //         }
        //         res.status(200).json({
        //             message:
        //                 'User successfully deleted'
        //         });
        //     })

        // User.findByIdAndRemove({_id: req.params.id}, 
        // 				(err, user) => {
        // if (err)
        // res.json(err);
        // else
        // res.json('Removed successfully');
        // });
    });

// UPDATE - PUT /api/users/1
router.route('/users/:id')
    .put(function (req, res) {
        User.findById(req.params.id,
            function (err, user) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                user.firstName = req.body.firstName;
                user.lastName = req.body.lastName;
                user.age = req.body.age;
                user.mobileNumber = req.body.mobileNumber;
                user.email = req.body.email;
                user.password = req.body.password;
                // user.updateOne();
                user.save(function (err) {
                    if (err) {
                        res.status(500).json(err.stack);
                        return;
                    }

                    res.status(200).json({
                        message:
                            'User updated!'
                    });
                });
            });
    });

// exporting all routes
module.exports = router;