export class Movie {
    _id: string;
    movieName: string;
    //movieImage: string;
    certified: string;
    language: string;
    
}