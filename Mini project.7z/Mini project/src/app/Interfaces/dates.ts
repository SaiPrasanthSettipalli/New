import { ShowTimings } from './show-timings';

export interface Dates {
    dates:String;
    showTimings:ShowTimings[];
}
