import { Component, OnInit } from '@angular/core';
import { MovieService } from 'src/app/services/movie.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-select-location',
  templateUrl: './select-location.component.html',
  styleUrls: ['./select-location.component.css']
})
export class SelectLocationComponent implements OnInit {
  allLocations: any;
  currentLocation: String;
  currentLanguage: String;
  allLanguages: any;
  allTheatres: String;
  allMovies: String;
  show: boolean = true;
  currentMovie: any;
  constructor(private movieService: MovieService, private _router: Router) { }

  ngOnInit() {
    this.movieService.getAllLocations().subscribe((allLocations: any) => this.allLocations = allLocations);
  }
  showMethod(show) {
    console.log("Hii" + this.show)
    this.show = !show;
  }
  onClick(location) {
    this.show = false;
    this.currentLocation = location;
    this.movieService.location = location
    this.movieService.getAllLanguages(location).subscribe((allLanguages: any) => { this.allLanguages = allLanguages; });

  }

  onClickLa(language) {
    this.currentLanguage = language;
    console.log(this.currentLocation + "    " + language);
    this._router.navigate(['movies',this.currentLocation,this.currentLanguage]);
    this.movieService.getAllMovies(this.currentLocation, language).subscribe((allMovies: any) => { this.allMovies = allMovies; console.log(allMovies) });
  }
  onClickMovies(movieName) {
    this.currentMovie = movieName;
    console.log("movie" + movieName);
    /* this._router.navigate(['theatres',this.currentLocation,this.currentLanguage,movieName]); */
    this.movieService.getAllTheatres(this.currentLocation, this.currentLanguage, movieName).subscribe((allTheatres: any) => { this.allTheatres = allTheatres; console.log(allTheatres) });

  }
  onClickTheatres(theatreName, date, time) {
    console.log("theatreName is " + theatreName);
    this._router.navigate(['seat', this.currentLocation, this.currentLanguage, this.currentMovie, theatreName, date, time]);
  }

}
