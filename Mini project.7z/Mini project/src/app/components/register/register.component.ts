import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MovieService } from 'src/app/services/movie.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  constructor(private formBuilder: FormBuilder, private router: Router,private movieService:MovieService) { }
  registerForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  model:any=[];
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      mobileNum: ['', [Validators.required,Validators.pattern("^[6-9][0-9]{9}")]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      confirmpassword: ['', Validators.required]

    });
  }
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
  //   console.log(this.model.firstName);
  //  this.movieService.createUser(this.model);

  //   let firstName = this.registerForm.controls.firstName.value;
  //   //let lastName = this.registerForm.controls.lastName.value;
  //   let email = this.registerForm.controls.email.value;
  

  //   if (email) {

  //     alert('Registration Successfully Done')



  //     this.router.navigate(['login']);
     
  //   }
  //   else {

  //     this.invalidLogin = true;
  //     alert("Invalid Registration")
  //   }
  // }
  let password = this.registerForm.controls.password.value;
  let confirmpassword = this.registerForm.controls.confirmpassword.value;
  console.log(this.model)
  if(password==confirmpassword){
  this.movieService.createUser(this.model).subscribe((data)=>{
    if(data==1 ){
      Swal.fire({
        icon:"success",
        title:"Registered Successfully",
        text:""
      })

  this.router.navigate(['/login'])}
  else{
    Swal.fire({
      icon:"error",
      title:"Oops...!",
      text:"User Already Exists..."
    })

  }
});
  }
  else{
    Swal.fire({
      icon:"error",
      title:"Oops...",
      text:"Password and Confirm Password should be same "
    })
  
  }

}
}