import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AddMovieComponent } from './components/add-movie/add-movie.component';
import { ViewMovieComponent } from './components/view-movie/view-movie.component';
import { SeatSelectionComponent } from './components/seat-selection/seat-selection.component';
import { SelectLocationComponent } from './components/select-location/select-location.component';
import { SelectTheatreComponent } from './select-theatre/select-theatre.component';
import { ViewLanguagesComponent } from './view-languages.component';
import { SelectshowtimingsComponent } from './selectshowtimings.component';
import { MovieFormComponent } from './movie-form/movie-form.component';
import { ViewSeatComponent } from './components/view-seat/view-seat.component';



const routes: Routes = [
  { path:'',component: HomeComponent},
  { path:'home', component: HomeComponent },
  { path:'login', component: LoginComponent },
  { path:'register', component: RegisterComponent},
  { path:'add-movie', component: AddMovieComponent},
  { path:'movies/:location/:language', component: ViewMovieComponent},
  { path:'seat/:location/:language/:movieName/:theatreName/:date/:time', component: SeatSelectionComponent},
  {path:'seat',component:SeatSelectionComponent},
  {path:'locations', component: SelectLocationComponent},
  {path:'view-theatre', component:SelectTheatreComponent},
  {path:'view-languages',component:ViewLanguagesComponent},
  {path:'selectTime',component:SelectshowtimingsComponent},
  {path:'movieForm',component:MovieFormComponent},
 
  {path :'view-seat', component:ViewSeatComponent}
  
  
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
