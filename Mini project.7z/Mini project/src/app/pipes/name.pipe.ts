import { Pipe, PipeTransform } from '@angular/core';
import { Movie} from '../model/movie.model';


@Pipe({
  name: 'name'
})
export class NamePipe implements PipeTransform {

  transform(moviesList: any, searchText: any) {
		let updatedMoviesList: Movie[];

		if (searchText) {
			updatedMoviesList = moviesList.filter(movie =>
				movie.movieName.toLowerCase()
					.startsWith(searchText.toLowerCase()));
			console.log(updatedMoviesList.length);
			console.log(updatedMoviesList);
		}
		else
			updatedMoviesList = moviesList;

		return updatedMoviesList;
	}

}
