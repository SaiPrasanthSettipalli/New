import { Component, OnInit, ɵConsole } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../services/movie.service';

@Component({
  selector: 'app-select-theatre',
  templateUrl: './select-theatre.component.html',
  styleUrls: ['./select-theatre.component.css']
})
export class SelectTheatreComponent implements OnInit {
  location:String;
  language:String;
  movieName:String;
  allTheatres:any=[];
  dates1:any=[];
  timings:any={};

  constructor(private _route:ActivatedRoute,private movieService:MovieService,private router:Router) {
   
   }

   theatre1(model:any){
     this.movieService.theatreName=model; 
     this.dates1=this.allTheatres.dates;
     this.movieService.getshowDates(model).subscribe((data)=>{
       this.dates1=data;
       console.log(data)
     });
     
   }
   showTiming(time){
     this.movieService.time=time;
     this.router.navigate(['./seat'])
   }

   showTimings(dates)
   {
     this.movieService.dates=dates;
    this.movieService.getshowtimings(dates).subscribe((data)=>{
      this.timings=data;
      
    })
   }
  ngOnInit() {
    
    this.movieService.getAllTheatres(this.movieService.location,this.movieService.language,this.movieService.movieName).subscribe((allTheatres:any)=>{this.allTheatres=allTheatres;});
    
  }

  

}
