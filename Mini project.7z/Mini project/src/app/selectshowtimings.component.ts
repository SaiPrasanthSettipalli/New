import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectshowtimings',
  templateUrl: './selectshowtimings.component.html',
  styleUrls: ['./selectshowtimings.component.css']
})
export class SelectshowtimingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
