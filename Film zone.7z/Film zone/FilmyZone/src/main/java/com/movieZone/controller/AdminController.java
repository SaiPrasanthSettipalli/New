package com.movieZone.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.movieZone.dto.AllLocations;
import com.movieZone.dto.Dates;
import com.movieZone.dto.Languages;
import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.Theatres;
import com.movieZone.dto.TimeSlots;
import com.movieZone.dto.User;
import com.movieZone.service.FilmService;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200")
public class AdminController
{
	@Autowired
	private FilmService service;
	@PostMapping("/saveUser")
	public Integer saveData(@RequestBody User user)
	{
		return service.saveData(user);
		
	}
	
	@GetMapping("/validateLogin")
	public Integer validateLogin(@RequestParam("email") String emailId, @RequestParam("password") String password)
	{
		
		//System.out.println("in controller");
			 return service.validateLogin(emailId,password);
			 
	}
	
	@GetMapping("/movieList")
	public List<Movies> getMoviesList(@RequestParam("location") String location) {
		
		return service.getMoviesList(location);
		
	}

	@GetMapping("/getAllLocations")
	public List<Location> getAllLocations() {
		return service.getAllLocations();
	}
	@GetMapping("/getAllLanguages")
	public List<String> getAllLanguages(@RequestParam("location") String location) {
		
		return service.getAllLanguages(location);
	}
	@GetMapping("/getAllMovies")
	public List<Movies> getAllMovies(@RequestParam("location") String location, @RequestParam("language") String language){
		return service.getAllMovies(location, language);
	}
	@GetMapping("/getAllLocationsNames")
	public Set<String> getAllLocationNames(){
		List<String> allLocations= service.getAllLocationNames();
		Set<String> hSet = new HashSet<String>(); 
        for (String x : allLocations) 
            hSet.add(x); 
        return hSet;
	}
	
	@PostMapping("/addLocation")
	public Location addLocation(@RequestBody Location loc)
	{
		//System.out.println(loc);
		return service.addLocation(loc);
		
	}
	@GetMapping("/getTheatres")
	public List<Theatres> getAllTheatres(@RequestParam("location") String location, @RequestParam("language") String language,@RequestParam("movieName") String movieName) {
		return service.getAllTheatres(location, language, movieName);
	}
	@GetMapping("/getShowDate")
	public List<String> getShowDate(@RequestParam("location") String location, @RequestParam("language") String language,@RequestParam("movieName") String movieName,@RequestParam("theatreName") String theatreName){
		List<Dates> date= service.getShowDates(location, language, movieName, theatreName);
		List<String> dates=new ArrayList<>();
		for(Dates date1:date)
			dates.add(date1.getDates());
		return dates;
		
		
	}
	@GetMapping("/getShowTimings")
	public List<String> getShowTimings(@RequestParam("location") String location, @RequestParam("language") String language,@RequestParam("movieName") String movieName,@RequestParam("theatreName") String theaterName,@RequestParam("dates") String dates){
		List<TimeSlots> timeSlots=service.getShowTimings(location, language, movieName, theaterName, dates);
		List<String> time=new ArrayList<>();
		for(TimeSlots slots:timeSlots)
			time.add(slots.getShowTime());
		return time;
		
	}
	@GetMapping("/getSeats")
	public Integer getSeats(@RequestParam("location") String location, @RequestParam("language") String language,@RequestParam("movieName") String movieName,@RequestParam("theatreName") String theaterName,@RequestParam("dates") String dates,@RequestParam("showTimings") String showTimings){		
			//System.out.println("In controller seats");
			return service.showSeats(location, language, movieName, theaterName, dates, showTimings);
		}
	@GetMapping("/getBlockedSeats")
	public List<Integer> getBlockedSeats(@RequestParam("location") String location, @RequestParam("language") String language,@RequestParam("movieName") String movieName,@RequestParam("theatreName") String theaterName,@RequestParam("dates") String dates,@RequestParam("showTimings") String showTimings){		
			//System.out.println("In controller seats");
			return service.getBookedSeats(location, language, movieName, theaterName, dates, showTimings);
		}
	@PostMapping("/setseats")
	public void booking(@RequestParam("location") String location,@RequestParam("language") String language,@RequestParam("movieName") String movieName,@RequestParam("theatreName") String theaterName,@RequestParam("dates") String date,@RequestParam("showTimings") String showTimings,@RequestParam("bookedseats") List<Integer>seats)
	{
		System.out.println("hello");
		service.booking(location, language, movieName, theaterName, date, showTimings, seats);
	}

	@GetMapping("/bookSeats")
	public String bookSeats(@RequestParam("location") String location, @RequestParam("language") String language,@RequestParam("movieName") String movieName,@RequestParam("theatreName") String theaterName,@RequestParam("dates") String dates,@RequestParam("showTimings") String showTimings,@RequestParam("seats") List<Integer> seats){		
			System.out.println("In gygy");
			return service.bookSeats(location, language, movieName, theaterName, dates, showTimings,seats);
		}


}