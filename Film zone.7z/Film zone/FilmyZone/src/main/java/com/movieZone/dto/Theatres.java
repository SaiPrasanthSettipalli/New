package com.movieZone.dto;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;

public class Theatres
{
	
	@Id
	private String theatreName;
	private List<Dates> dates;
	@Override
	public String toString() {
		return "Theatres [theatreName=" + theatreName+ ", dates=" + dates + "]";
	}

	public Theatres() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Theatres(String theatreName, List<Dates> dates) {
		super();
		this.theatreName = theatreName;
	
		this.dates = dates;
	}

	public List<Dates> getDates() {
		return dates;
	}

	public void setDates(List<Dates> dates) {
		this.dates = dates;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	
		
}
