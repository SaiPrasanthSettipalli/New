package com.movieZone.dto;

import java.util.List;

import org.springframework.data.annotation.Id;

public class Dates {
	private List<TimeSlots> showTimings; 
	@Id
	private String dates;
	public List<TimeSlots> getShowTimings() {
		return showTimings;
	}
	public void setShowTimings(List<TimeSlots> showTimings) {
		this.showTimings = showTimings;
	}
	
	@Override
	public String toString() {
		return "Dates [showTimings=" + showTimings + ", dates=" + dates + "]";
	}
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public Dates() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dates(List<TimeSlots> showTimings, String dates) {
		super();
		this.showTimings = showTimings;
		this.dates = dates;
	}

}
