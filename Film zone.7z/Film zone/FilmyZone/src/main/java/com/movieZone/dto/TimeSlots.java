package com.movieZone.dto;

import java.util.List;

import org.springframework.data.annotation.Id;

public class TimeSlots 
{
	@Id
	private String showTime;
	private int noOfSeats;
	List<Integer> bookedSeats;
	public TimeSlots() {
		super();
		
	}
	public List<Integer> getBookedSeats() {
		return bookedSeats;
	}
	public void setBookedSeats(List<Integer> bookedSeats) {
		this.bookedSeats = bookedSeats;
	}
	
	public TimeSlots(String showTime, int noOfSeats, List<Integer> bookedSeats) {
		super();
		this.showTime = showTime;
		this.noOfSeats = noOfSeats;
		this.bookedSeats = bookedSeats;
	}
	@Override
	public String toString() {
		return "TimeSlots [showTime=" + showTime + ", noOfSeats=" + noOfSeats + ", bookedSeats=" + bookedSeats + "]";
	}
	public TimeSlots(String showTime, int noOfSeats) {
		super();
		this.showTime = showTime;
		this.noOfSeats = noOfSeats;
	}
	public String getShowTime() {
		return showTime;
	}
	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	 
}
