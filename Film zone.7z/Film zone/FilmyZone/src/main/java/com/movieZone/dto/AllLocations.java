package com.movieZone.dto;

import java.util.List;

public class AllLocations {
	private List<Location> allLocations;

	public AllLocations() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AllLocations(List<Location> allLocations) {
		super();
		this.allLocations = allLocations;
	}

	public List<Location> getAllLocations() {
		return allLocations;
	}

	public void setAllLocations(List<Location> allLocations) {
		this.allLocations = allLocations;
	}

	@Override
	public String toString() {
		return "AllLocations [allLocations=" + allLocations + "]";
	}
	
	

}
