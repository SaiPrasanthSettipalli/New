package com.movieZone.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.movieZone.dto.Dates;
import com.movieZone.dto.Languages;
import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.Theatres;
import com.movieZone.dto.TimeSlots;
import com.movieZone.dto.User;

@Repository
public class FilmyDaoImpl implements FilmyDao {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Integer saveData(User user) {
		List<User> user1=mongoTemplate.findAll(User.class);
		for(User user2:user1)
			if(user2.getEmail().equalsIgnoreCase(user.getEmail()))
				return 0;
		
		mongoTemplate.save(user);
		return 1;

	}

	@Override
	public Integer validateLogin(String emailId, String password) {
		
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(emailId));
		User user=mongoTemplate.findOne(query, User.class);
		if(user!=null) {
			System.out.println(user.getPassword());
		if(user.getPassword().equals(password) && user.getFirstName().equalsIgnoreCase("admin")) {
			System.out.println(user);
			return 2;
		}
		
		else if(user.getPassword().equals(password))
			return 1;
		}
		return 0;
	}

	public List<Location> getAllLocations() {

		return mongoTemplate.findAll(Location.class);
	}

	@Override
	public Location addLocation(Location loc) {
		System.out.println(loc);
		List<String> allLanguages=getAllLanguages(loc.getCityName());
		for (String language : allLanguages) {
			List<Movies> allMovies=getAllMovies(loc.getCityName(), language);
			for (Movies movie : allMovies) {
				List<Theatres> allTheatres=getAllTheatres(loc.getCityName(), language, movie.getMovieName());
				for (Theatres theatre : allTheatres) {
					List<Dates> allDates=getShowDates(loc.getCityName(), language, movie.getMovieName(), theatre.getTheatreName());
					for (Dates date : allDates) {
						List<TimeSlots> timeSlots=getShowTimings(loc.getCityName(), language, movie.getMovieName(), theatre.getTheatreName(),date.getDates());
						for (TimeSlots time : timeSlots) {
							List<Integer> allSeats=setBookedSeats(loc.getCityName(), language, movie.getMovieName(), theatre.getTheatreName(), date.getDates(), time.getShowTime());
							time.setBookedSeats(allSeats);
							System.out.println("in adding"+time);
							System.out.println("in loc"+loc);
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return mongoTemplate.insert(loc);
	}
	
	  @Override public List<Movies> getMovieList(String language) { List<Languages>
	  l = mongoTemplate.findAll(Languages.class); for (Languages languages : l) {
	  if (languages.getLanguage().equals(language)) {
	  
	  }
	  
	  }
	  
	  return null; }
	 

	@Override
	public List<String> getAllLocationsName() {

		List<String> allLocationNames = new ArrayList<>();
		List<Location> allLocations = getAllLocations();
		for (Location location : allLocations) {
			allLocationNames.add(location.getCityName());

		}
		return allLocationNames;
	}

	@Override
	public List<String> getAllLanguages(String location) {
		//System.out.println("Entered location" + location);
		List<Location> allLocations = getAllLocations();
		Set<String> languageNames = new HashSet<String>();
		for (Location location2 : allLocations) {
			//System.out.println(location2 + "   all locations");
			if (location2.getCityName().equalsIgnoreCase(location)) {
				List<Languages> allLanguages = location2.getLanguages();
				for (Languages language : allLanguages) {
					languageNames.add(language.getLanguage());

				}

			}

		}
		List<String> l=new ArrayList<>(languageNames);
		return l;
	}
	@Override
public List<Movies> getAllMovies(String location,String language){
		List<Location> allLocations=getAllLocations();
		List<Movies> allMovies=new ArrayList<>();
		for (Location location2 : allLocations) {
			if(location2.getCityName().equalsIgnoreCase(location)) {
				List<Languages> allLanguages = location2.getLanguages();
				for (Languages languageName: allLanguages) {
					if(languageName.getLanguage().equalsIgnoreCase(language)) {
					allMovies.addAll(languageName.getMovieList());
					}
					
				}
			}
			
			
		}
		return allMovies;
}
	@Override
	public List<Theatres> getAllTheatres(String location,String language,String movieName){
		//System.out.println("In location"+location);
		//System.out.println("In language"+language);
		//System.out.println("In location"+movieName);
		List<Movies> allMovies=getAllMovies(location, language);
		
		List<Theatres> allTheatres=new ArrayList<>();
		if(allMovies!=null)
		for (Movies movies : allMovies) {
			if(movies.getMovieName().equalsIgnoreCase(movieName)) {
				//System.out.println("In movies"+movies.getTheatre());
				allTheatres.addAll(movies.getTheatre());
			
		}
	}
		return allTheatres;
}

	@Override
	public List<Dates> getShowDates(String location, String language, String movieName, String theaterName) {
		List<Theatres> theaters=getAllTheatres(location, language, movieName);
		List<Dates> date1=new ArrayList<>();
		for(Theatres theater:theaters) {
			if(theater.getTheatreName().equalsIgnoreCase(theaterName)) {
				List<Dates> date=theater.getDates();
				for(Dates dates:date)
					date1.add(dates);
				
			}
		}
		return date1;
	}

	@Override
	public List<TimeSlots> getShowTimings(String location, String language, String movieName, String theaterName,
			String date) {
		List<Dates> dates=getShowDates(location, language, movieName, theaterName);
		List<TimeSlots> showTime=new ArrayList<>();
		List<String>time=new ArrayList<>();
		for(Dates date1:dates) {
			if(date1.getDates().equalsIgnoreCase(date)) {
				showTime=date1.getShowTimings();
			}
		}	
		return showTime;
	}

	@Override
	public Integer showSeats(String location, String language, String movieName, String theaterName, String date,
			String showTimings) {
		List<TimeSlots> timeslots=getShowTimings(location, language, movieName, theaterName, date);
		for(TimeSlots time:timeslots) {
			//System.out.println(time);
			if(time.getShowTime().equalsIgnoreCase(showTimings)) {
				//System.out.println("In service"+time.getNoOfSeats());
				return time.getNoOfSeats();
			}
		}
		
		return null;
	}

	@Override
	public void booking(String location, String language, String movieName, String theaterName, String date,
			String showTimings, List<Integer> seats) {
		Query query=new Query();
		Dates dates=new Dates();
		List<TimeSlots> show=new ArrayList<>();
		List<Dates> dates1=new ArrayList<>();
		Theatres theatres=new Theatres();
		List<Theatres> theatre=new ArrayList<>();
		Movies movie=new Movies();
		List<Movies> movies=new ArrayList<>(); 
		Languages languages=new Languages();
		List<Languages> lang=new ArrayList<>();
		Location location1=new Location();
		
		List<TimeSlots> time=getShowTimings(location, language, movieName, theaterName, date);
		for(TimeSlots slots:time) {
			if(slots.getShowTime().equalsIgnoreCase(showTimings))
				slots.setBookedSeats(seats);
			show.add(slots);
			dates.setShowTimings(show);
			dates1.add(dates);
			theatres.setDates(dates1);
			theatre.add(theatres);
			movie.setTheatre(theatre);
			movies.add(movie);
			languages.setMovieList(movies);
			lang.add(languages);
			location1.setLanguages(lang);
			location1.setCityName(location);
			mongoTemplate.save(location1);
		}
		
	}

	
	public List<Integer> setBookedSeats(String location, String language, String movieName, String theaterName,
			String date, String showTimings) {
		TimeSlots timee=new TimeSlots();
		System.out.println(location+" "+language+" "+movieName+" "+theaterName+" "+date+" "+showTimings);
		List<Integer> bookedSeats=new ArrayList<>();
		List<TimeSlots> timeslots=getShowTimings(location, language, movieName, theaterName, date);
		for(TimeSlots time:timeslots) {
			//System.out.println(time);
			if(time.getShowTime().equalsIgnoreCase(showTimings)) {
				//System.out.println("In service"+time.getNoOfSeats());
				time.getNoOfSeats();
				for (int i = 0; i < time.getNoOfSeats(); i++) {
					
					bookedSeats.add(i);
				}
			}
		}
		//System.out.println(bookedSeats);
		timee.setBookedSeats(bookedSeats);
		System.out.println(timee.getBookedSeats());
		return bookedSeats;
	}

	@Override
	public List<Integer> getBookedSeats(String location, String language, String movieName, String theaterName,
			String date, String showTimings) {
		List<TimeSlots> allTimeSlots=getShowTimings(location, language, movieName, theaterName, date);
				for (TimeSlots timeSlots : allTimeSlots) {
					if(timeSlots.getShowTime().equalsIgnoreCase(showTimings)) {
						System.out.println("hii"+timeSlots.getBookedSeats());
						return timeSlots.getBookedSeats();
					}
					
				}
		return null;
	}

	@Override
	public String bookSeats(String location, String language, String movieName, String theaterName, String dates,
			String showTimings, List<Integer> seats) {
		// TODO Auto-generated method stub
		 System.out.println(location+" "+language+" "+movieName+" "+theaterName+" "+dates+" "+showTimings+" "+seats);
		 return "OKK";
	}
		
	
	
}