package com.movieZone.service;

import java.util.List;

import com.movieZone.dto.AllLocations;
import com.movieZone.dto.Dates;
import com.movieZone.dto.Languages;
import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.Theatres;
import com.movieZone.dto.TimeSlots;
import com.movieZone.dto.User;

public interface FilmService 
{
	
	public Integer saveData(User user);

	public Integer validateLogin(String emailId, String password);

	public Location addLocation(Location loc);
	List<Movies> getAllMovies(String location, String language);

	public List<Movies> getMoviesList(String Location);

	public List<Location> getAllLocations();
	public List<String> getAllLocationNames();

	public List<String> getAllLanguages(String location);
	List<Theatres> getAllTheatres(String location,String language,String movieName);
	List<Dates> getShowDates(String location,String language,String movieName,String theaterName);
	List<TimeSlots> getShowTimings(String location,String language,String movieName,String theaterName,String date);
	public Integer showSeats(String location,String language,String movieName,String theaterName,String date,String showTimings);
	List<Integer> getBookedSeats(String location,String language,String movieName,String theaterName,String date,String showTimings);

	public void booking(String location,String language,String movieName,String theaterName,String date,String showTimings,List<Integer> seats);

	public String bookSeats(String location, String language, String movieName, String theaterName, String dates,
			String showTimings, List<Integer> seats);

	

}
