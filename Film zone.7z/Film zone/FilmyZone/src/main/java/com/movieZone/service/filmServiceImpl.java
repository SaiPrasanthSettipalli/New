package com.movieZone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieZone.dao.FilmyDao;
import com.movieZone.dto.AllLocations;
import com.movieZone.dto.Dates;
import com.movieZone.dto.Languages;
import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.Theatres;
import com.movieZone.dto.TimeSlots;
import com.movieZone.dto.User;

@Service
public class filmServiceImpl implements FilmService{

	@Autowired
	private FilmyDao dao;
	
	@Override
	public Integer saveData(User user) 
	{
		return dao.saveData(user);
	}

	@Override
	public Integer validateLogin(String emailId, String password) {
		return dao.validateLogin(emailId,password);
	}

	@Override
	public Location addLocation(Location loc) {
		
		return dao.addLocation(loc);
	}

	@Override
	public List<Movies> getMoviesList(String location) {
		
		return dao.getMovieList(location);
	}

	@Override
	public List<Location> getAllLocations() {
		// TODO Auto-generated method stub
		return dao.getAllLocations();
	}

	@Override
	public List<String> getAllLocationNames() {
		// TODO Auto-generated method stub
		return dao.getAllLocationsName();
	}

	@Override
	public List<String> getAllLanguages(String location) {
		// TODO Auto-generated method stub
		return dao.getAllLanguages(location);
	}

	@Override
	public List<Movies> getAllMovies(String location, String language) {
		// TODO Auto-generated method stub
		return dao.getAllMovies(location, language);
	}

	@Override
	public List<Theatres> getAllTheatres(String location, String language, String movieName) {
		return dao.getAllTheatres(location, language, movieName);
		
	}

	@Override
	public List<Dates> getShowDates(String location, String language, String movieName, String theaterName) {
		// TODO Auto-generated method stub
		return dao.getShowDates(location, language, movieName, theaterName);
	}

	@Override
	public List<TimeSlots> getShowTimings(String location, String language, String movieName, String theaterName,
			String date) {
		// TODO Auto-generated method stub
		return dao.getShowTimings(location, language, movieName, theaterName, date);
	}

	@Override
	public Integer showSeats(String location, String language, String movieName, String theaterName, String date,
			String showTimings) {
		// TODO Auto-generated method stub
		return dao.showSeats(location, language, movieName, theaterName, date, showTimings);
	}

	@Override
	public void booking(String location, String language, String movieName, String theaterName, String date,
			String showTimings, List<Integer> seats) {
		dao.booking(location, language, movieName, theaterName, date, showTimings, seats);
		
	}

	@Override
	public List<Integer> getBookedSeats(String location, String language, String movieName, String theaterName,
			String date, String showTimings) {
		return dao.getBookedSeats(location, language, movieName, theaterName, date, showTimings);
	}

	@Override
	public String bookSeats(String location, String language, String movieName, String theaterName, String dates,
			String showTimings, List<Integer> seats) {
		// TODO Auto-generated method stub
		return dao.bookSeats(location, language, movieName, theaterName, dates, showTimings,seats);
	}

	
	
}
