package com.movieZone.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="User1")
public class User {
	
	private String firstName,mobileNum,email,password,confirmpassword,role;
	private int walletAmount;
	
	public User() {
		super();
	}

	public User(String firstName, String mobileNum, String email, String password, String confirmpassword, String role,
			int walletAmount) {
		super();
		this.firstName = firstName;
		this.mobileNum = mobileNum;
		this.email = email;
		this.password = password;
		this.confirmpassword = confirmpassword;
		this.role = role;
		this.walletAmount = walletAmount;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(int walletAmount) {
		this.walletAmount = walletAmount;
	}

	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", mobileNum=" + mobileNum + ", email=" + email + ", password="
				+ password + ", confirmpassword=" + confirmpassword + ", role=" + role + ", walletAmount="
				+ walletAmount + "]";
	}
}