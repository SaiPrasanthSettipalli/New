export interface ShowTimings {
    showTime:String;
    noOfSeats:number;
}
