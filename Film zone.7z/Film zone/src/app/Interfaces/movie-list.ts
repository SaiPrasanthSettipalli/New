import { Theatre } from './theatre';

export interface MovieList {
    movieName:String;
    genre:String;
    trailerLink:String;
    posterLink:String;
    cast:String;
    theatre:Theatre[];

}
