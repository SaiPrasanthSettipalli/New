import { Dates } from './dates';

export interface Theatre {
    price:String;
    theatreName:String;
    dates:Dates[];
}
