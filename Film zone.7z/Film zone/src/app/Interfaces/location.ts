import { Languages } from './languages';

export interface Location {
    cityName:String;
    languages:Languages[];
}
