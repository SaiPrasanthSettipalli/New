import { MovieList } from './movie-list';

export interface Languages {
    language:String;
    movieList:MovieList[];
}
