import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { NamePipe } from './pipes/name.pipe';
import { AddMovieComponent } from './components/add-movie/add-movie.component';
//import { ListMovieComponent } from './components/list-movie/list-movie.component';
import { SeatSelectionComponent } from './components/seat-selection/seat-selection.component';
import { ViewMovieComponent } from './components/view-movie/view-movie.component';
import { SelectLocationComponent } from './components/select-location/select-location.component';
import { SelectTheatreComponent } from './select-theatre/select-theatre.component';
import { ViewLanguagesComponent } from './view-languages.component';
import { SelectshowtimingsComponent } from './selectshowtimings.component';
import { MovieFormComponent } from './movie-form/movie-form.component';
import { ViewSeatComponent } from './components/view-seat/view-seat.component';



//import { FileUploadModule, FileSelectDirective } from 'ng2-file-upload';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    NamePipe,
    AddMovieComponent,
  // FileSelectDirective,
    //ListMovieComponent,
    SeatSelectionComponent,
    ViewMovieComponent,
    SelectLocationComponent,
    SelectTheatreComponent,
    ViewLanguagesComponent,
    SelectshowtimingsComponent,
    MovieFormComponent,
  ViewSeatComponent
    

  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
