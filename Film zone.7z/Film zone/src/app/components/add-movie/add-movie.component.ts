import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MovieService} from '../../services/movie.service';
//import {FileUploader,FileSelectDirective,} from 'ng2-file-upload';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {

  movieForm: FormGroup;
  submitted: boolean = false;
  movies:any=[];

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    
    private movieService: MovieService) { }

  ngOnInit() {
    this.movieForm = this.formBuilder.group({
      _id: [],
      cityName: ['', Validators.required],
      language: ['', Validators.required],
      movieName:['', Validators.required],
      genre:['', Validators.required],
      trailerLink:['', Validators.required],
      posterLink:['', Validators.required],
      theatreName:['', Validators.required],
      dates:['', Validators.required],
      showTime:['', Validators.required],
      noOfSeats:['', Validators.required],
        price:['', Validators.required],

    });

    // this.movieService.uploadFile();
  }
  // uploader = this.movieService.uploader;
  
  onSubmit() {
    this.submitted = true;
    if (this.movieForm.invalid) {
      return;
    }
    this.movieService.saveMovie(this.movies).subscribe(data => {
        alert(this.movieForm.controls.movieName.value
          + ' record is added successfully ..!');
        this.router.navigate(['home']);
      })
  
}
}
