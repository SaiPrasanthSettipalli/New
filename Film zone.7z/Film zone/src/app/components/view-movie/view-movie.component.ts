import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Movie } from '../../model/movie.model';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-view-movie',
  templateUrl: './view-movie.component.html',
  styleUrls: ['./view-movie.component.css']
})
export class ViewMovieComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean = false;
  location:String;
  language:String;
 movie:{}
  movieId: string;
  movieList:any;
  constructor(private formBuilder: FormBuilder, private _route: ActivatedRoute,private router: Router, private route: ActivatedRoute,
  private movieService: MovieService) {
  // this.route.params.subscribe(params => this.movieId = params['id']);
  // console.log(this.movieId);
 }

  //logOff Product
  logOutProduct(): void {
    if (localStorage.getItem("username") != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }
  ngOnInit() {
    this.location=this._route.snapshot.paramMap.get("location");
    this.language=this._route.snapshot.paramMap.get("language");

   /*  if (this.movieId != null) {
      if (!this.movieId) {
        alert('Invalid Action');
        this.router.navigate(['/home']);
        return;
      }
      this.movieService.getMoviesById(this.movieId).subscribe(data => {
        this.movie=data
      });
    }
    else {
      this.router.navigate(['/login']);

    } */
    this.movieService.getAllMovies(this.location,this.language).subscribe((data=>{
      this.movieList=data;
      console.log(data)
    }))

  }//end of ngOnInit() function

  // onSubmit() {
  //   this.submitted = true;
  //   if (this.editForm.invalid) {
  //     return;
  //   }
  //   this.productsService.updateProduct(this.editForm.value)
      
  //     .subscribe(data => {
  //       this.router.navigate(['list-product']);
  //        Swal.fire({
  //         title: 'Update',
  //         text: 'Record is Updated Successfully',
  //       })
  //     }, error => {
  //       alert(error);
  //     });
  bookSeats(){
    this.router.navigate(['/seat'])
  }
  movieName(value:any){
    console.log("In viewMovie"+value)
    this.movieService.location=this.location;
    this.movieService.language=this.language;
    this.movieService.movieName=value;
    this.router.navigate(['./view-theatre'])

  }
  }





