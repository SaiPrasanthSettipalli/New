import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-seat',
  templateUrl: './view-seat.component.html',
  styleUrls: ['./view-seat.component.css']
})
export class ViewSeatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
