import { Component, OnInit } from '@angular/core';
import { MovieService } from 'src/app/services/movie.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-seat-selection',
  templateUrl: './seat-selection.component.html',
  styleUrls: ['./seat-selection.component.css']
})
export class SeatSelectionComponent implements OnInit {

  location:String
  language:String;
  movieName:String;
  time:String;
  seats:any;
  theatreName:String;
  date:String;
  seatForm: FormGroup;
  name:any;
  count:any;
  selectedSeats:any[]=[];
  //seat:any[]=[-3];
  bookedSeats=[1,2,3,4];
  flag:boolean
    constructor(private movieService:MovieService,private _route: ActivatedRoute,private formBuilder:FormBuilder) { }
  inArray(seatNo){
    
    var index=this.bookedSeats.indexOf(seatNo);
    
    if(index==-1){
      this.flag=true;
    }
    else
    this.flag=false;
   
    return this.flag;
  }
    arrayTwo(n: number): number[] {
    console.log("arrayTwo"+[...Array(n).keys()]);
    return [...Array(n).keys()];
  }

  checkbr(seat:any){
    if(seat%10==0){
      console.log("br:"+seat);
      return true;
    }
    return false;
  }

  ngOnInit() {

    /* this. seatForm = this.formBuilder.group({
      seat: ['', ],
  
     // role: ['', Validators.required]

    });
    this.location=this._route.snapshot.paramMap.get("location");
    this.language=this._route.snapshot.paramMap.get("language");
    this.movieName=this._route.snapshot.paramMap.get("movieName");
    this.theatreName=this._route.snapshot.paramMap.get("theatreName");
      this.date=this._route.snapshot.paramMap.get("date");
    this.time=this._route.snapshot.paramMap.get("time");
    console.log(this.location+" "+this.language+" "+this.movieName); */
    this.movieService.getAllSeats().subscribe((seats)=>{
      this.seats=seats;
    });
    this.movieService.getAllBlockedSeats();
  }
  onSubmit(){
   // console.log(document.querySelector('.seat').checked);
   console.log("selected seats:"+this.selectedSeats.length);
   alert("selected seats:"+this.selectedSeats);
   this.movieService.bookSeats(this.selectedSeats);
    // let value=this.seatForm.controls.seat.value;
    // alert("Seats Booked Successfully"+value);
  }
  changed(seat:any){
    console.log(seat);
    this.selectedSeats.push(seat);
    console.log("selected");
    // this.seats.map((value)=>{
    //   if(value.checked){
    //     this.count=this.count+1;
    //     alert(this.count)
    //   }
    // })

  }
}
