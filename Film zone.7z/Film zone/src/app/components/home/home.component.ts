import { Component, OnInit } from '@angular/core';
import { Movie } from '../../model/movie.model';
import { Router } from '@angular/router';
import { MovieService } from '../../services/movie.service';
import { FormGroup ,FormBuilder,Validators} from '@angular/forms';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

   // creating an Array of User class
   movies: Movie[];
   // filtering by name
   searchText: any;
   userForm:FormGroup;
   
  
 
 
   // Constructor Dependency Injection
   constructor(private router: Router
     , private movieService: MovieService,private formBuilder:FormBuilder) { }
 
   // logOff User
   logOutUser(): void {
     if (localStorage.getItem("username") != null) {
       localStorage.removeItem("username");
       this.router.navigate(['/login']);
     }
   }
 
   // loading all users as soon as component
   // gets loaded
   ngOnInit() {
    this. userForm = this.formBuilder.group({
      location: ['', [Validators.required]],})
       this.movieService.getMovies()
         .subscribe(data => {
           this.movies = data;
         });
     
    
   }
 
 
   // Delete User
   deleteMovie(movie: Movie): void {
     let result = confirm("Do you want to delete Movie?");
     if (result) {
       this.movieService.deleteMovie(movie._id)
         .subscribe(data => {
           this.movies = this.movies.filter
             (u => u !== movie);
         })
       alert(`${movie.movieName} record is deleted ..!`);
 
       // this will return me empty list
       //   .subscribe(data => {
       //   this.users = <User[]>data;
       // })
     }
   }
   // Modify User
   editMovie(movie: Movie): void {
     // localStorage.removeItem("editUserId");
     // localStorage.setItem("editUserId",
     //   user.id.toString());
     //  this.router.navigate(['edit-user']);
 
     this.router.navigate(['view-movie', movie._id]);
   }
 
   // Add New User
   addMovie(): void {
     this.router.navigate(['add-movie']);
   }
   onSubmit(){
   
     let location=this.userForm.controls.location.value;
     this.movieService.location=location;
     this.router.navigate(['./view-languages'])
   }
   
 }
 
