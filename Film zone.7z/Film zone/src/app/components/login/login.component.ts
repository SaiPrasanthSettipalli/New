import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MovieService } from 'src/app/services/movie.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;

  constructor(private formBuilder:FormBuilder, private router:Router,private movieService:MovieService) { }

  ngOnInit() {
    this. loginForm = this.formBuilder.group({
      email: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required],
     // role: ['', Validators.required]

    });
  }

  onSubmit() {
     
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }
    

    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;
    //let role = this.loginForm.controls.role.value;
  
    this.movieService.validateLogin(username,password).subscribe((data:any)=>{
      console.log(data);
      if(data==1){
        Swal.fire({
          icon:"success",
          title:"Login Successfully Done...",
          text:""
        })
      this.router.navigate(['./locations'])
      }
      else if(data==2){
        Swal.fire({
          icon:"success",
          title:"Login Successfully Done...",
          text:""
        })
      this.router.navigate(['./add-movie']);
      }
      else{
        Swal.fire({
          icon:"error",
          title:"Oops..!",
          text:"Invalid Details"
        })
      }
    });


  //   if(role=="admin")
  //   {
  //     localStorage.setItem("username",username);
  //     this.router.navigate(['add-movie']);
  //     alert('Login Successfully Done')
  //   }
  //   else if(role=="user"){
  //   localStorage.setItem("username",username);
  //   this.router.navigate(['list-movie']);
  //   alert('Login Successfully Done')
  // }
  // else{
    
  //     this.invalidLogin = true;
  //     alert("Invalid Login")
  //   }
  // }
  // this.router.navigate(['add-movie']);
}
}
