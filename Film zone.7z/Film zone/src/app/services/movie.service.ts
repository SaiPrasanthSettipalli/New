import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Movie } from '../model/movie.model';

import { FileUploader, FileDropDirective, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';

@Injectable({
  providedIn: 'root'
})
export class MovieService {


  firstName: any;
  email: any;
  mobileNum: any;
  password: any;
  confirmPassword: any;
  role: String = "user";
  walletAmount: number = 20000;
  location: any;
  language: any;
  formLanguages = new Array();
  movieName: any;
  theatreName: any;
  dates: any = [];
  time: any;
  foo: any = new Array();
  constructor(private httpc: HttpClient) { }
  baseUrl: string = "http://localhost:3000/api/movies";


  saveMovie(data: any) {
    let showTimings = {
      "showTime": data.showTime,
      "noOfSeats": data.noOfSeats,
      "bookedSeats": this.foo
    }
    let dates = {
      "dates": data.dates,
      "showTimings": [showTimings]
    }
    let theatre = {
      "theatreName": data.theatreName,
      "dates": [dates],
    }
    let movieList = {
      "movieName": data.movieName,
      "genre": data.genre,
      "trailerLink": data.trailerLink,
      "posterLink": data.posterLink,
      "theatre": [theatre],
      "price": data.price
    }
    let languages = {
      "language": data.language,
      "movieList": [movieList]
    }
    let input = {
      "cityName": data.name,
      "languages": [languages]
    }
    console.log("input" + input);
    console.log("timings" + showTimings)
    return this.httpc.post("http://localhost:9098/admin/addLocation", input);

  }

  createUser(data: any) {
    console.log("In Service " + data.firstName);
    let val = {
      "firstName": data.firstName,
      "mobileNum": data.mobileNum,
      "email": data.email,
      "password": data.password,
      "confirmpassword": data.confirmpassword,
      "role": this.role,
      "walletAmount": this.walletAmount
    }
    console.log("input is" + val.firstName)
    return this.httpc.post("http://localhost:9098/admin/saveUser", val);

  }
  validateLogin(username: any, password: any) {
    console.log(username + "    " + password);
    return this.httpc.get("http://localhost:9098/admin/validateLogin?email=" + username + "&password=" + password);
  }
  getAllLocations() {
    return this.httpc.get("http://localhost:9098/admin/getAllLocationsNames");
  }
  getAllLanguages(location) {
    console.log("location selected is " + location);
    return this.httpc.get("http://localhost:9098/admin/getAllLanguages?location=" + location)
  }
  getAllMovies(location, language) {
    return this.httpc.get("http://localhost:9098/admin/getAllMovies?location=" + location + "&language=" + language);
  }
  getAllTheatres(location, language, movieName) {
    console.log("MovieName is" + movieName);
    return this.httpc.get("http://localhost:9098/admin/getTheatres?location=" + location + "&language=" + language + "&movieName=" + movieName);
  }
  getAllSeats() {
    console.log(this.location + " " + this.language + " " + this.movieName + " " + this.theatreName + " " + this.dates + " " + this.time);
    return this.httpc.get("http://localhost:9098/admin/getSeats?location=" + this.location + "&language=" + this.language + "&movieName=" + this.movieName + "&theatreName=" + this.theatreName + "&dates=" + this.dates + "&showTimings=" + this.time)
  }
  getAllBlockedSeats() {
    console.log(this.location + " " + this.language + " " + this.movieName + " " + this.theatreName + " " + this.dates + " " + this.time);
    console.log("in service  " + this.httpc.get("http://localhost:9098/admin/getBlockedSeats?location=" + this.location + "&language=" + this.language + "&movieName=" + this.movieName + "&theatreName=" + this.theatreName + "&dates=" + this.dates + "&showTimings=" + this.time));
    this.httpc.get("http://localhost:9098/admin/getBlockedSeats?location=" + this.location + "&language=" + this.language + "&movieName=" + this.movieName + "&theatreName=" + this.theatreName + "&dates=" + this.dates + "&showTimings=" + this.time)

  }
  bookSeats(selectedSeats: any[]) {
    this.foo.push(selectedSeats);
    console.log("hii in service book seats" + selectedSeats);
    this.httpc.get("http://localhost:9098/admin/bookSeats?location=" + this.location + "&language=" + this.language + "&movieName=" + this.movieName + "&theatreName=" + this.theatreName + "&dates=" + this.dates + "&showTimings=" + this.time + "seats=" + selectedSeats)
  }
  getMovies() {
    return this.httpc.get<Movie[]>(this.baseUrl);
  }

  //get todos by id
  getMoviesById(id: string) {
    return this.httpc.get<Movie>(this.baseUrl + "/" + id);
  }

  //add todo
  createMovie(movie: any) {
    let movies = {
      "cityname": movie.name,
      "language": movie.language,
      "movieName": movie.movieName,
      "genre": movie.genre,
      "trailerLink": movie.trailerLink,
      "posterLink": movie.posterLink,
      "cast": movie.cast,
      "theatreName": movie.theatreName,
      "dates": movie.dates,
      "showTime": movie.showTime,
      "noOfSeats": movie.noOfSeats,
      "price": movie.price
    }
    console.log(movies)
    return this.httpc.post("http://localhost:9098/admin/addLocation", movies);
    //here user in parantheses is body of user
  }

  //modify todo
  updateMovie(movie: Movie) {
    return this.httpc.put(this.baseUrl + '/' + movie._id, movie);
  }

  //delete todo
  deleteMovie(id: string) {
    return this.httpc.delete(this.baseUrl + "/" + id);

  }

  getshowDates(theatreName) {
    return this.httpc.get("http://localhost:9098/admin/getShowDate?location=" + this.location + "&language=" + this.language + "&movieName=" + this.movieName + "&theatreName=" + theatreName);
  }
  getshowtimings(date) {
    return this.httpc.get("http://localhost:9098/admin/getShowTimings?location=" + this.location + "&language=" + this.language + "&movieName=" + this.movieName + "&theatreName=" + this.theatreName + "&dates=" + date);
  }
}
