import { Component, OnInit } from '@angular/core';
import { MovieService } from '../services/movie.service';
import { Languages } from '../Interfaces/languages';
import { MovieList } from '../Interfaces/movie-list';
import { Theatre } from '../Interfaces/theatre';
import { Dates } from '../Interfaces/dates';
import { ShowTimings } from '../Interfaces/show-timings';

@Component({
  selector: 'app-movie-form',
  templateUrl: './movie-form.component.html',
  styleUrls: ['./movie-form.component.css']
})
export class MovieFormComponent implements OnInit {
  model:any=[];
  loc:Location;
  lan:Languages;
  mov:MovieList;
  the:Theatre;
  dat:Dates;
  st:ShowTimings;

  constructor(private movieService: MovieService) { }

  ngOnInit() {
  }
  saveMovie(){
    console.log("hiii")
        this.movieService.saveMovie(this.loc);
  }

}
