import { Component, OnInit } from '@angular/core';
import { MovieService } from './services/movie.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-languages',
  templateUrl: './view-languages.component.html',
  styleUrls: ['./view-languages.component.css']
})
export class ViewLanguagesComponent implements OnInit {

  languages:any;
  constructor(private movieService:MovieService,private router:Router) { }

  ngOnInit() {
    this.movieService.getAllLanguages(this.movieService.location).subscribe((data)=>{
      this.languages=data;
      console.log(this.languages)
    })
  }
  lang(value:any){

    this.movieService.language=value;
    console.log("in service"+value);
    this.router.navigate(['./view-movie'])
    
    
  }

}
