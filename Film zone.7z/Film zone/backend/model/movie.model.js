// STEP1: IMPORT MONGOOSE MODULE
var mongoose = require('mongoose');

// STEP2: CREATE SCHEMA OBJECT
const Schema = mongoose.Schema;

// STEP3: CREATE OUR SCHEMA WITH OPTIONALLY ADDING VALIDATIONS
// SIMPLE SCHEMA
let Movie = new Schema({
    id:{ type: String },       
    movieName: { type: String },
   // movieImage:{ type: String },
    certified: { type: String },
    language: { 
        type: String        // default: 'Open' 
    },
    
    
    
});
// STEP4: EXPORT SCHEMA
module.exports = mongoose.model('Movie', Movie);