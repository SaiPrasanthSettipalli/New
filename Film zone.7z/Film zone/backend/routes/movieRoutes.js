// for routes
const express = require('express');
// for mongoose third party module
const mongoose = require('mongoose');
// for connection string
const path=require ('path');
const config = require('../config/db');
// configuring router OR Creating an object of Router
const router = express.Router();
//import from quote.model.js Module
let Movie = require('../model/movie.model');
const multer = require('multer');
var fs = require('fs');


// STEP3 - CONNECT MONGODB DATABASE
//Connecting Mongodb server
mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;
//when connection open
db.once('open', function () {
    console.log('Connection Open with MongoDB Server ..!');
});
//check for db error
db.on('error', function (err) {
    console.log("Error : " + err.stack);
});

const serverPath = '../public/images';

var fn;
// file uploading logic
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, serverPath);
    },
    filename: (req, file, cb) => {
        //let ext = path.extname(file.originalname);
        // var filename = `${file.originalname}-${new Date().getTime()}${ext}`;
        var filename = file.originalname;
        cb(null, filename);
        fn = filename;
        console.log(fn);
    }
});

// GET /api/users
router.route('/movies').get(function (req, res) {
    Movie.find(function (err, movies) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        res.status(200).json(movies);
    });
});

// 	User.findById(req.params.id, 'firstName lastName age mobileNumber email password',
// GET /api/users/1
router.route('/movies/:id')
    .get(function (req, res) {
        Movie.findById(req.params.id, { __v: 0 },
            function (err, movie) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json(movie);
            });
    });

// CREATE - POST - /api/users
router.route('/movies').post(function (req, res) {
    var movie = new Movie();
     movie.movieName = req.body.movieName;
    // movie.movieImage = req.body.movieImage;
     movie.certified = req.body.certified;
     movie.language=req.body.language;
        

    movie.save(function (err) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        console.log("added");
        res.status(200).json({
            message
                : 'Movie Created !'
        })
    })
//     var upload = multer({ storage: storage })
//     .fields([{ name: 'movieImage', maxCount: 1 }]);

// upload(req, res, function (err) {
//     if (err) {
//         res.status(500).json(
//             {
//                 message: "Failed to upload file",
//                 error: err
//             });
//         return;
//     }
//     //If upload success save user details
    // var movie = new Movie(req.body);
    // if (req.files.movieImage && req.files.movieImage.length > 0) {
      //  movie.movieImage = `http://${req.get('host')}/public/images/${req.files.movieImage[0].filename}`;
        // console.log(movie.movieImage);
     //}
    
    // if (req.body.movieImage && req.body.movieImage.length > 0) {
        //user.photo = `http://${req.get('host')}/public/images/${req.files.photo[0].filename}`;
        // movie.movieImage = `http://${req.get('host')}/public/images/${req.body.movieImage.filename}`;
       // movie.movieImage =  `http://${req.get('host')}/public/images/${fn}`;
    //     console.log(movie.movieImage);
    // }

    // movie.save((err, doc) => {
    //     if (err) {
    //         res.status(500).json(
    //             {
    //                 message: "Error in adding movie details",
    //                 error: err
    //             });
    //     }
    //     else {
    //         res.status(200).json(
    //             {
    //                 message: 'Movie details added successfully',
    //                 movie: doc,
    //                 location: `/api/movies/${doc._id}`
    //             });
    //     }
    // });
});


// DELETE /api/users/1
router.route('/movies/:id')
    .delete(function (req, res) {
        // remove(), findByIdAndRemove(), deleteOne()
        Movie.deleteOne({ _id: req.params.id },
            function (err, user) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json({
                    message:
                        'Movie successfully deleted'
                });
            })

        // User.remove({ _id: req.params.id },
        //     function (err, user) {
        //         if (err) {
        //             res.status(500).json(err.stack);
        //             return;
        //         }
        //         res.status(200).json({
        //             message:
        //                 'User successfully deleted'
        //         });
        //     })

        // User.findByIdAndRemove({_id: req.params.id}, 
        // 				(err, user) => {
        // if (err)
        // res.json(err);
        // else
        // res.json('Removed successfully');
        // });
    });

// UPDATE - PUT /api/users/1
router.route('/movies/:id')
    .put(function (req, res) {
        Movie.findById(req.params.id,
            function (err, movie) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                movie.movieName = req.body.movieName;
    // movie.movieImage = req.body.movieImage;
    movie.certified = req.body.certified;
    movie.language=req.body.language;
 // user.updateOne();
                movie.save(function (err) {
                    if (err) {
                        res.status(500).json(err.stack);
                        return;
                    }

                    res.status(200).json({
                        message:
                            'Movie updated!'
                    });
                });
            });
    });

// exporting all routes
module.exports = router;