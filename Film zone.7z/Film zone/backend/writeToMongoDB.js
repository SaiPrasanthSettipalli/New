const path = require('path');
var grid = require("gridfs-stream");
var fs = require("fs");

module.exports.writeToDB = function (fn, connection, mongooseDrv) {
    if (connection !== "undefined") {
        console.log(connection.readyState.toString());

        var filesrc = path.join(__dirname, "./public/images/" + fn);

        //Establish connection between Mongo and GridFS
        grid.mongo = mongooseDrv.mongo;

        //Open the connection and write file
        var gridfs = grid(connection.db);
        if (gridfs) {

            //create a stream, this will be
            //used to store file in database
            var streamwrite = gridfs.createWriteStream({
                //the file will be stored with the name
                filename: fn
            });

            //create a readstream to read the file
            //from the filestored folder
            //and pipe into the database
            fs.createReadStream(filesrc).pipe(streamwrite);

            //Complete the write operation
            streamwrite.on("close", function (file) {
                console.log("Write written successfully in database");
            });
        } else {
            console.log("Sorry No Grid FS Object");
        }
    }

    console.log("done");
} 