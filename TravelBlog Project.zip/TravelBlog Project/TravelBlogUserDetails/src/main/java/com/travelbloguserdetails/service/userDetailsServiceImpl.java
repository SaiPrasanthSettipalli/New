package com.travelbloguserdetails.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travelbloguserdetails.dao.userDetails;
import com.travelbloguserdetails.dto.User;

@Service
public class userDetailsServiceImpl implements userDetailsService{

	@Autowired
	userDetails userDetails;
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userDetails.addUser(user);
	}
	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return userDetails.getUsers();
	}

}
