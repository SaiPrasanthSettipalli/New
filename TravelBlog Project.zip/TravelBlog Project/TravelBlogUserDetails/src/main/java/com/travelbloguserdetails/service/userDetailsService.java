package com.travelbloguserdetails.service;

import java.util.List;

import com.travelbloguserdetails.dto.User;

public interface userDetailsService {
	public User addUser(User user);
	public List<User> getUsers();

}
