package com.travelbloguserdetails.dao;

import java.util.List;

import com.travelbloguserdetails.dto.User;

public interface userDetails {
	public User addUser(User user);
	public List<User> getUsers();

}
