package com.travelbloguserdetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.travelbloguserdetails.dto.User;
import com.travelbloguserdetails.service.userDetailsService;

@RestController
@RequestMapping("/TravelBloguserController")
public class userDetailsController {
	@Autowired
	userDetailsService userDetailsService;

	@PostMapping("/addUser")
	public User addUsers(@RequestBody User user) {
		System.out.println("in new controller user");
		return userDetailsService.addUser(user);
	}
	@GetMapping("/getUsers")
	public List<User> getUsers(){
		System.out.println("in get users");
		return userDetailsService.getUsers();
	}
	
}
