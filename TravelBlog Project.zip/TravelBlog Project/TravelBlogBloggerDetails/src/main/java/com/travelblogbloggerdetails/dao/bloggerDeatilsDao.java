package com.travelblogbloggerdetails.dao;

import java.util.List;

import com.travelblogbloggerdetails.dto.BloggerDetails;
import com.travelblogbloggerdetails.dto.User;

public interface bloggerDeatilsDao {
	public BloggerDetails addBlog(BloggerDetails bloggerDetails);
	public List<BloggerDetails> searchByDestination(String destinations);
	public List<BloggerDetails> getAllBlogs();
	 public List<User> getUsers(); 


}
