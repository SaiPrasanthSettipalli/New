package com.travelblogbloggerdetails.service;

import java.util.List;

import com.travelblogbloggerdetails.dto.BloggerDetails;
import com.travelblogbloggerdetails.dto.User;

public interface bloggerDeatilsService {
	public BloggerDetails addBlog(BloggerDetails bloggerDetails);
	public List<BloggerDetails> searchByDestination(String destinations);
	public List<BloggerDetails> getAllBlogs();
	 public List<User> getUsers(); 

}
