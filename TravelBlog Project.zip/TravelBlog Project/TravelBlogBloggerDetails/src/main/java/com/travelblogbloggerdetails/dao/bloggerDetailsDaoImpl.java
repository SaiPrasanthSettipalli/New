package com.travelblogbloggerdetails.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.travelblogbloggerdetails.dto.BloggerDetails;
import com.travelblogbloggerdetails.dto.User;

@Repository
public class bloggerDetailsDaoImpl implements bloggerDeatilsDao{

	@Autowired
	MongoTemplate mongoTemplate;

	
	  @Autowired 
	  protected RestTemplate restTemplate;
	  
	  protected String serviceUrl;
	  
	  
	  public bloggerDetailsDaoImpl(String serviceUrl) { 
		  this.serviceUrl =serviceUrl.startsWith("http") ? serviceUrl : "http://" + serviceUrl;
	  
	  }
	  
	  public bloggerDetailsDaoImpl() {
		  
	  }
	 


	@Override
	public BloggerDetails addBlog(BloggerDetails bloggerDetails) {
		// TODO Auto-generated method stub
		Long number=bloggerDetails.getContactNo();
		List<User> usersData=getUsers();
		for (User user : usersData) {
			if(user.getContactNo().equals(number)) {
				return mongoTemplate.insert(bloggerDetails);

			}
			
		}
		return null;
	}

	

	public List<BloggerDetails> searchByDestination(String destinations) {
		// TODO Auto-generated method stub
		List<BloggerDetails> details=mongoTemplate.findAll(BloggerDetails.class);
		List<BloggerDetails> blogdetails=new ArrayList<BloggerDetails>();
		for(BloggerDetails detail:details) {
			if(detail.getDestinations().equalsIgnoreCase(destinations)) {
				System.out.println("in dao blog details");
				blogdetails.add(detail);
			
			}
		}
		return blogdetails;
	}



	@Override
	public List<BloggerDetails> getAllBlogs() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(BloggerDetails.class);
	}



	
	  @Override 
	  public List<User> getUsers() {
	  
	  User[] accounts =restTemplate.getForObject(serviceUrl+"/TravelBloguserController/getUsers",User[].class); 
	  return Arrays.asList(accounts);
	  
	  }
	 
}
