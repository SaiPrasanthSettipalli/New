package com.cg.project.bean;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="user")
public class Registration {

	private String userName;
	private String mailId;
	private Long phoneNumber;
	private String password;
	private String technicianMail;
	public String getTechnicianMail() {
		return technicianMail;
	}
	public void setTechnicianMail(String technicianMail) {
		this.technicianMail = technicianMail;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Registration(String userName, String mailId, Long phoneNumber, String password, String technicianMail) {
		super();
		this.userName = userName;
		this.mailId = mailId;
		this.phoneNumber = phoneNumber;
		this.password = password;
		this.technicianMail = technicianMail;
	}
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Registration [userName=" + userName + ", mailId=" + mailId + ", phoneNumber=" + phoneNumber
				+ ", password=" + password + ", technicianMail=" + technicianMail + "]";
	}
	
	
	
}
