package com.cg.project.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="billing")
public class Billing {

	private Registration registration;
	private List<Logistics> logistics;
	public Registration getRegistration() {
		return registration;
	}
	public void setRegistration(Registration registration) {
		this.registration = registration;
	}
	public List<Logistics> getLogistics() {
		return logistics;
	}
	public void setLogistics(List<Logistics> logistics) {
		this.logistics = logistics;
	}
	@Override
	public String toString() {
		return "Billing [registration=" + registration + ", logistics=" + logistics + "]";
	}
	public Billing(Registration registration, List<Logistics> logistics) {
		super();
		this.registration = registration;
		this.logistics = logistics;
	}
	public Billing() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
