package com.cg.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;
import com.cg.project.dao.HealthDao;

@Service
public class HealthServiceImp1 implements HealthService{

	@Autowired
	HealthDao healthDao;
	@Override
	public Integer createRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return healthDao.createRegistration(registration);
	}
	@Override
	public Integer addTests(Logistics logistics) {
		// TODO Auto-generated method stub
		return healthDao.addTests(logistics);
	}
	@Override
	public List<Registration> getUserDetails() {
		// TODO Auto-generated method stub
		return healthDao.getUserDetails();
	}
	
	@Override
	public Integer validateByMailPswd(String mailId, String pswd) {
		// TODO Auto-generated method stub
		return healthDao.validateByMailPswd(mailId,pswd);
	}
	@Override
	public List<Registration> getTechnicianDetails() {
		// TODO Auto-generated method stub
		return healthDao.getTechnicianDetails();
	}
	@Override
	public Integer booking(String usermail, String tecnicianMail) {
		// TODO Auto-generated method stub
		return healthDao.booking(usermail, tecnicianMail);
	}
	@Override
	public List<Registration> getDetails(String technicianMail) {
		// TODO Auto-generated method stub
		return healthDao.getDetails(technicianMail);
	}
	@Override
	public List<Logistics> viewTests() {
		// TODO Auto-generated method stub
		return healthDao.viewTests();
	}
	@Override
	public Integer addEquipment(String name, Integer price) {
		// TODO Auto-generated method stub
		return healthDao.addEquipment(name,price);
	}
	@Override
	public List<Logistics> getEquipment() {
		// TODO Auto-generated method stub
		return healthDao.getEquipment();
	}
	@Override
	public Integer saveChanges(String ename, Integer eprice) {
		// TODO Auto-generated method stub
		return healthDao.saveChanges(ename,eprice);
	}
	@Override
	public void deleteEquipment(String ename) {
		// TODO Auto-generated method stub
		healthDao.delete(ename);
		
	}
	@Override
	public Integer saveTestChanges(String tname, Integer tprice) {
		// TODO Auto-generated method stub
		return healthDao.saveTestChanges(tname,tprice);
	}
	@Override
	public void deleteTests(String tname) {
		// TODO Auto-generated method stub
		healthDao.deleteTests(tname);
		
	}
	

}
