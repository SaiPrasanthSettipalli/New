package com.cg.project.bean;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="logistics")
public class Logistics {
	private String testName;
	private int testPrice;
	private String equipmentName;
	private int equipmentPrice;
	
	public Logistics(String testName, int testPrice, String equipmentName, int equipmentPrice) {
		super();
		this.testName = testName;
		this.testPrice = testPrice;
		this.equipmentName = equipmentName;
		this.equipmentPrice = equipmentPrice;
	}
	public Logistics() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public int getTestPrice() {
		return testPrice;
	}
	public void setTestPrice(int testPrice) {
		this.testPrice = testPrice;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public int getEquipmentPrice() {
		return equipmentPrice;
	}
	public void setEquipmentPrice(int equipmentPrice) {
		this.equipmentPrice = equipmentPrice;
	}
	@Override
	public String toString() {
		return "Logistics [testName=" + testName + ", testPrice=" + testPrice + ", equipmentName=" + equipmentName
				+ ", equipmentPrice=" + equipmentPrice + "]";
	}
	
	
}
