package com.movieZone.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.movieZone")
public class Filmyzone2Application {

	public static void main(String[] args) {
		SpringApplication.run(Filmyzone2Application.class, args);
	}

}
