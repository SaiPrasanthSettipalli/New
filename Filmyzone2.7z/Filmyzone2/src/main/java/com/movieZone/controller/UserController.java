package com.movieZone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.movieZone.dto.Movies;
import com.movieZone.dto.User;
import com.movieZone.service.FilmService;

@RestController
public class UserController 
{
	@Autowired
	private FilmService service;
	
	@PostMapping("/save")
	public void saveData(@RequestBody User user)
	{
	    if(user==null)
	    	System.out.println("data is not proper");
	    else {
		      service.saveData(user);
		 System.out.println("data is stored successfully");
		}
		
	}
	
	@PostMapping("/validateLogin")
	public Integer validateLogin(@RequestParam("email") String emailId, @RequestParam("password") String password)
	{
		Integer res=-2;
		if(emailId.equals(null) || password.equals(null) )
			System.out.println("please provide data");
		else
		{
			 res=service.validateLogin(emailId,password);
			if(res==1)
				System.out.println("Login Successful");
			else if(res==0)
				System.out.println("Invalid Password");
			else
				System.out.println("Invalid Email");
			
		}
		return res;
	}
	
	@GetMapping("/movieList")
	public List<Movies> getMoviesList(@RequestParam("location") String location) {
		
		return service.getMoviesList(location);
		
	}

}
