package com.movieZone.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="location1")
public class Location {
	
	private String cityName;
	private List<Languages> languages;
	
	public Location() {
		super();
	}

	@Override
	public String toString() {
		return "Location [cityName=" + cityName + ", languages=" + languages + "]";
	}

	public Location(String cityName, List<Languages> languages) {
		super();
		this.cityName = cityName;
		this.languages = languages;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public List<Languages> getLanguages() {
		return languages;
	}

	public void setLanguages(List<Languages> languages) {
		this.languages = languages;
	}

	
}
