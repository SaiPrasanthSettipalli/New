package com.movieZone.dto;

import java.util.Date;
import java.util.List;

public class Theatres
{
	
	private String theatreName;
	private List<TimeSlots> showTimings; 
	private List<String> noOfDays;
	
	@Override
	public String toString() {
		return "Theatres [theatreName=" + theatreName + ", showTimings=" + showTimings + ", noOfDays=" + noOfDays + "]";
	}

	public Theatres() {
		super();
	}

	public Theatres(String theatreName, List<TimeSlots> showTimings, List<String> noOfDays) {
		super();
		this.theatreName = theatreName;
		this.showTimings = showTimings;
		this.noOfDays = noOfDays;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public List<TimeSlots> getShowTimings() {
		return showTimings;
	}

	public void setShowTimings(List<TimeSlots> showTimings) {
		this.showTimings = showTimings;
	}

	public List<String> getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(List<String> noOfDays) {
		this.noOfDays = noOfDays;
	}

		
}
