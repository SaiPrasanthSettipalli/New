package com.movieZone.dto;

import java.util.List;

public class Languages 
{
	private String language;
	private List<Movies> movieList;
	
	
	@Override
	public String toString() {
		return "Languages [language=" + language + ", movieList=" + movieList + "]";
	}
	public Languages() {
		super();
	}
	public Languages(String language, List<Movies> movieList) {
		super();
		this.language = language;
		this.movieList = movieList;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<Movies> getMovieList() {
		return movieList;
	}
	public void setMovieList(List<Movies> movieList) {
		this.movieList = movieList;
	}
	
	

}
