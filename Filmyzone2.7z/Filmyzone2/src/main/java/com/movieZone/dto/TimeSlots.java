package com.movieZone.dto;

public class TimeSlots 
{
	private String showTime;
	private int noOfSeats;
	public TimeSlots() {
		super();
	}
	@Override
	public String toString() {
		return "TimeSlots [showTime=" + showTime + ", noOfSeats=" + noOfSeats + "]";
	}
	public TimeSlots(String showTime, int noOfSeats) {
		super();
		this.showTime = showTime;
		this.noOfSeats = noOfSeats;
	}
	public String getShowTime() {
		return showTime;
	}
	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	 
}
