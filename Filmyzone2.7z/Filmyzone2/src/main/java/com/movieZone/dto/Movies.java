package com.movieZone.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

public class Movies 
{
    private String movieName,genre,trailerLink,posterLink;
    private List<String> cast;
    private List<Theatres> theatre;
    private int price;
	
    @Override
	public String toString() {
		return "Movies [movieName=" + movieName + ", genre=" + genre + ", trailerLink=" + trailerLink + ", posterLink="
				+ posterLink + ", cast=" + cast + ", theatre=" + theatre + ", price=" + price + "]";
	}

	public Movies() {
		super();
	}

	public Movies(String movieName, String genre, String trailerLink, String posterLink, List<String> cast,
			List<Theatres> theatre, int price) {
		super();
		this.movieName = movieName;
		this.genre = genre;
		this.trailerLink = trailerLink;
		this.posterLink = posterLink;
		this.cast = cast;
		this.theatre = theatre;
		this.price = price;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getTrailerLink() {
		return trailerLink;
	}

	public void setTrailerLink(String trailerLink) {
		this.trailerLink = trailerLink;
	}

	public String getPosterLink() {
		return posterLink;
	}

	public void setPosterLink(String posterLink) {
		this.posterLink = posterLink;
	}

	public List<String> getCast() {
		return cast;
	}

	public void setCast(List<String> cast) {
		this.cast = cast;
	}

	public List<Theatres> getTheatre() {
		return theatre;
	}

	public void setTheatre(List<Theatres> theatre) {
		this.theatre = theatre;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

		    
}
