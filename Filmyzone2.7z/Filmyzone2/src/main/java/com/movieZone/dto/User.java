package com.movieZone.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="User")
public class User {
	
	private String name,mobileNum,emailId,password,confirmPassword,role;
	private int walletAmount;
	
	public User() {
		super();
	}

	public User(String name, String mobileNum, String emailId, String password, String confirmPassword, String role,
			int walletAmount) {
		super();
		this.name = name;
		this.mobileNum = mobileNum;
		this.emailId = emailId;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.role = role;
		this.walletAmount = walletAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(int walletAmount) {
		this.walletAmount = walletAmount;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", mobileNum=" + mobileNum + ", emailId=" + emailId + ", password=" + password
				+ ", confirmPassword=" + confirmPassword + ", role=" + role + ", walletAmount=" + walletAmount + "]";
	}
	
}