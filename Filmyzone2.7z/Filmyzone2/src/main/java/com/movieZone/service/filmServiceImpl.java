package com.movieZone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieZone.dao.FilmyDao;
import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.User;

@Service
public class filmServiceImpl implements FilmService{

	@Autowired
	private FilmyDao dao;
	
	@Override
	public void saveData(User user) 
	{
		dao.saveData(user);
	}

	@Override
	public Integer validateLogin(String emailId, String password) {
		return dao.validateLogin(emailId,password);
	}

	@Override
	public Location addLocation(Location loc) {
		
		return dao.addLocation(loc);
	}

	@Override
	public List<Movies> getMoviesList(String location) {
		
		return dao.getMovieList(location);
	}

	
	
}
