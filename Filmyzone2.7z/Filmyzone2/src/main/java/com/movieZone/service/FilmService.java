package com.movieZone.service;

import java.util.List;

import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.User;

public interface FilmService 
{
	
	public void saveData(User user);

	public Integer validateLogin(String emailId, String password);

	public Location addLocation(Location loc);

	public List<Movies> getMoviesList(String Location);

}
