package com.movieZone.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.movieZone.dto.Languages;
import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.User;

@Repository
public class FilmyDaoImpl implements FilmyDao{

	@Autowired
	private MongoTemplate mongoTemplate;
	@Override
	public void saveData(User user) 
	{
		mongoTemplate.save(user);
		
	}
	
	@Override
	public Integer validateLogin(String emailId, String password) 
	{
		List<User> users=mongoTemplate.findAll(User.class);
		for (User user : users) 
		{
			if(user.getEmailId().equals(emailId))
			{
				if(user.getPassword().equals(password))
					return 1;
				else
					return 0;
			}
			
		}
		return -1;
	}

	
	
	public List<Location> getAllLocations(){
		return mongoTemplate.findAll(Location.class);
		
	}

	@Override
	public Location addLocation(Location loc) {
		System.out.println(getAllLocations());
		return mongoTemplate.save(loc);
	}

	@Override
	public List<Movies> getMovieList(String language) {
		List<Languages> l=mongoTemplate.findAll(Languages.class); 
	    for (Languages languages : l) 
	    {
			 if(languages.getLanguage().equals(language)) {
				 
			 }
				
		}
		
		return null;
	}

	
	

}
