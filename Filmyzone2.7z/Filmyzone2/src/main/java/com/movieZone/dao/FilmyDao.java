package com.movieZone.dao;

import java.util.List;

import com.movieZone.dto.Location;
import com.movieZone.dto.Movies;
import com.movieZone.dto.User;

public interface FilmyDao 
{
	
	public void saveData(User user);

	public Integer validateLogin(String emailId, String password);

	public Location addLocation(Location loc);

	public List<Location> getAllLocations();

	public List<Movies> getMovieList(String location);

	

}
