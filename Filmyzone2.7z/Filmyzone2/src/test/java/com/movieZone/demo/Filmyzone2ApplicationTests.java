package com.movieZone.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Filmyzone2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
