import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Observable, VirtualTimeScheduler } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ManagerService {
  
  usermail:any;
  techmailId:any;
  eName: any;
  eprice: any;
  tName: any;
  tPrice: any;

  constructor(private httpClient:HttpClient) { }
  validateLogin(mail,password){
    this.usermail=mail;
    console.log(mail,password);
    return this.httpClient.post("http://localhost:9456/registration/validateUser?mailId="+mail+"&password="+password," ");
  }
  addEquipment(name:String,price:number){
    console.log(name+" "+price)
    return this.httpClient.get("http://localhost:9456/registration/addEquipment/"+name+"/"+price);
  }

  submitTest(data:any){
let input={
    "testName":data.testName,
    "testPrice":data.testPrice
}
   return  this.httpClient.post("http://localhost:9456/registration/addTests",input);
  }
  viewTests():Observable<any>{
    return this.httpClient.get("http://localhost:9456/registration/viewTests");
  }
  viewCustomers(){
    return this.httpClient.get("http://localhost:9456/registration/getDetails/"+this.usermail);
  }
  createRegistration(data:any){
    
    console.log(data.name);
    let input={
      "userName":data.name,
      "mailId":data.mailId,
      "phoneNumber":data.phoneNumber,
      "password":data.password
    }
    return this.httpClient.post("http://localhost:9456/registration/userregistration",input);
  }
  viewTechnicians(){
    return this.httpClient.get("http://localhost:9456/registration/getTechnicianDetails");
  }
  bookTechnicians(tecnicianMail:any){
    console.log(this.usermail+" "+tecnicianMail);
    return this.httpClient.get("http://localhost:9456/registration/Booking/"+this.usermail+"/"+tecnicianMail);
  }
  viewEquipment(){
    return this.httpClient.get("http://localhost:9456/registration/viewEquipment");
  }
  saveEditedEquipment(eName: any, ePrice: any) {
    console.log(eName+" "+ePrice);
    return this.httpClient.get("http://localhost:9456/registration/saveChanges/"+eName+"/"+ePrice);
  }
  deleteEquipment(ename:String){
    console.log(ename);
    return this.httpClient.delete("http://localhost:9456/registration/delete/"+ename);
  }
  saveEditedTest(tPrice:any){
    console.log(this.tName+" "+tPrice);
    return this.httpClient.get("http://localhost:9456/registration/saveTestChanges/"+this.tName+"/"+tPrice)
  }
  deleteTest(tName:any){
    return this.httpClient.delete("http://localhost:9456/registration/deletetests/"+tName);
  }

}

