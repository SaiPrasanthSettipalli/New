import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-equip',
  templateUrl: './delete-equip.component.html',
  styleUrls: ['./delete-equip.component.css']
})
export class DeleteEquipComponent implements OnInit {

  equipment:any={};
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
     return this.managerService.viewEquipment().subscribe((data:any)=>{
      this.equipment=data;
    })
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view1(){
    this.router.navigate(['./viewEquipment']);
  }
  save(eName,eprice){
    console.log(eName+" and "+eprice);
    this.managerService.eName=eName;
    this.managerService.eprice=eprice; 
    this.router.navigate(['./editEquipment']);
    
  }
  delete(eName,eprice){
    this.managerService.deleteEquipment(eName).subscribe((data:any)=>{
      if(data==1){
      alert("deleted succesfully");
      this.router.navigate(['./viewEquipment'])
      }
    }); 
   }
}
