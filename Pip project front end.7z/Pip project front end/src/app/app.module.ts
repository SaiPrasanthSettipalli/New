import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ NgxPaginationModule } from 'ngx-pagination';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './project/registration.component';
import { HomeComponent } from './home.component';
import { ManagerLoginComponent } from './manager-login/manager-login.component';
import { FormsModule }   from '@angular/forms';
import {HttpClientModule} from "@angular/common/http";
import { ManagerPageComponent } from './manager-page.component';
import { AddEquipmentComponent } from './add-equipment.component';
import { AddTestsComponent } from './project/add-tests.component';
import { ViewTestsComponent } from './view-tests.component';
import {UserregistrationComponent} from './userregistration.component';
import { TechnicianComponent } from './technician.component';
import { ViewCustomersComponent } from './view-customers.component';
import { ConfirmEqualValidatorDirective } from './manager-login/confirmEqualValidatorDirective';
import { CustomerComponent } from './customer.component';
import { ViewtechniciansComponent } from './viewtechnicians.component';
import { ViewEquipmentComponent } from './view-equipment/view-equipment.component';
import { EditEquipmentComponent } from './edit-equipment/edit-equipment.component';
import { DeleteEquipComponent } from './delete-equip.component';
import { EditTesstComponent } from './edit-tesst.component';
import { DeleteTestComponent } from './delete-test.component';
import { CustomerViewEquipmentComponent } from './customer-view-equipment.component';
import { CustviewtestComponent } from './custviewtest.component';



  
@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    HomeComponent,
    ManagerLoginComponent,
    ManagerPageComponent,
    AddEquipmentComponent,
    AddTestsComponent,
    ViewTestsComponent,
    UserregistrationComponent,
    TechnicianComponent,
    ViewCustomersComponent,
    ConfirmEqualValidatorDirective,
    CustomerComponent,
    ViewtechniciansComponent,
    ViewEquipmentComponent,
    EditEquipmentComponent,
    DeleteEquipComponent,
    EditTesstComponent,
    DeleteTestComponent,
    CustomerViewEquipmentComponent,
    CustviewtestComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
    
  ],
  providers: [
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

